import example0Run from './example0';
import example1Run from './example1';
import example2Run from './example2';
import example3IQFlatRun from './example3.flat.iq';
import example3IQRun from './example3.iq';
import example3Run from './example3';
import example4Run from './example4';

// example2Run();
// example3Run();
// example3IQRun();
example3IQRun();
// example3IQFlatRun();
