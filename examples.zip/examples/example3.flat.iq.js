import {Block, SmartGraph} from '../src';

import props from './data/test1.iq.json';

const svg = document.querySelector('#svg');
let clickFn;
const config = {
  render: (svgRoot, node) => {
    svgRoot.append('rect').attr('width', 40).attr('height', 20).style('fill', 'rgba(125,125,125,.7)');
    svgRoot.on('click', d => {
      clickFn(d);
    })
  },
  groupBuilder: {
    active: true
    // skipProps: ['oid', 'shortDescr', 'IPAddressList', 'hostName', 'VMIdentifier', 'VMName', 'systemDescr', 'systemOid']
  },
  getSize: node => [
    40, 20, 1
  ],
  id: 'oid'
}

export default() => {
  const graph = new SmartGraph(svg, config);
  const {nodes, nodesCount, relationships} = props;

  let nodesIndex = [];
  let innerNodes = Object.keys(nodes).reduce((memo, item) => {
    nodes[item].forEach(node => nodesIndex.push(node.oid));
    return memo.concat(nodes[item]);
  }, []);

  let links = Object.keys(relationships).reduce((memo, item) => {
    relationships[item].forEach(rel => {
      const {downstreamNodeId, upstreamNodeId} = rel;
      const from = upstreamNodeId.split(':')[1];
      const to = downstreamNodeId.split(':')[1];
      memo.push([from, to]);
    });
    return memo;
  }, []);

  clickFn = d => graph.toggle(d);
  graph.setData({nodes: innerNodes, links});
  graph.zoomToExtent(0.8, 300, 500)
}
