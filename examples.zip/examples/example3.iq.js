import {Block, SmartGraph} from '../src';

import props from './data/test1.iq.json';

const svg = document.querySelector('#svg');

const types = {
  'ComputerSystem': {
    r: 86,
    g: 86,
    b: 86
  },
  'Service': {
    r: 125,
    g: 125,
    b: 255
  },
  'ProductInstance': {
    r: 125,
    g: 125,
    b: 200,
    height: 20
  },
  'VICluster': {
    r: 200,
    g: 200,
    b: 125
  }
}
let graph;
const config = {
  render: (svgRoot, node) => {

    const {className} = node;

    let root = new Block(svgRoot);
    root.build({
      x: 0,
      y: -20,
      z: 0,
      width: 20,
      length: 20,
      height: 4,
      radius: 20,
      r: node.sgGroup
        ? 255
        : 125,
      g: 125,
      b: 125,
      ...types[className]
    });

    svgRoot.on('click', d => {
      graph.toggle(d, false);
      // const {__sg} = d;
      // __sg.width = 140;
      // __sg.length = 40;
      // root.animate({height: 10, width: 40, length: 40});
      // console.log(d);
    })

    if (node.className === 'ComputerSystem') {
      new Block(svgRoot).build({
        x: 0,
        y: -20,
        z: 6,
        width: 20,
        length: 20,
        height: 4,
        radius: 20,
        r: 125,
        g: 125,
        b: 125,
        ...types[className]
      });

      new Block(svgRoot).build({
        x: 0,
        y: -20,
        z: 12,
        width: 20,
        length: 20,
        height: 4,
        radius: 20,
        r: 125,
        g: 125,
        b: 125,
        ...types[className]
      });
    }

    return root;
  },
  locationFn: 'iso',
  groupBuilder: {
    active: true,
    skipProps: ['oid']
  },
  getSize: () => [
    20, 20, 4
  ],
  id: 'oid'
}

export default() => {
  graph = new SmartGraph(svg, config);
  const {nodes, nodesCount, relationships} = props;

  let nodesIndex = [];
  let innerNodes = Object.keys(nodes).reduce((memo, item) => {
    nodes[item].forEach(node => nodesIndex.push(node.oid));
    return memo.concat(nodes[item]);
  }, []);

  let links = Object.keys(relationships).reduce((memo, item) => {
    relationships[item].forEach(rel => {
      const {downstreamNodeId, upstreamNodeId} = rel;
      const from = upstreamNodeId.split(':')[1];
      const to = downstreamNodeId.split(':')[1];
      memo.push([from, to]);
    });
    return memo;
  }, []);

  graph.setData({nodes: innerNodes, links});
  graph.zoomToExtent(0.8, 300, 500)
}
